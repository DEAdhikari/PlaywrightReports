import streamlit as st
import subprocess
import os
import json
import pandas as pd

TESTS_DIR = r"D:\PlaywrightUI\tests"

st.title("🎭 Playwright Test Runner with Step Timings")

# List all Python test scripts in the folder
scripts = [f for f in os.listdir(TESTS_DIR) if f.endswith(".py")]

# Allow selecting multiple scripts
selected_scripts = st.multiselect("Select test scripts:", scripts)

if st.button("Run Selected Scripts"):
    if not selected_scripts:
        st.warning("Please select at least one script to run.")
    else:
        for script in selected_scripts:
            st.markdown(f"### 📄 Results for `{script}`")
            try:
                result = subprocess.run(
                    ["python", script],
                    capture_output=True,
                    text=True,
                    cwd=TESTS_DIR
                )

                steps_output = result.stdout.strip()
                if steps_output:
                    try:
                        steps = json.loads(steps_output)

                        # Convert to DataFrame and format response times to 2 decimals
                        df = pd.DataFrame(steps)
                        df["Response Time (s)"] = df["Response Time (s)"].map(lambda x: f"{x:.2f}")

                        st.table(df)
                    except json.JSONDecodeError:
                        st.warning("Could not parse step timings.")
                else:
                    st.warning("No step timings found in output.")

                if result.stderr.strip():
                    st.error(result.stderr)

            except Exception as e:
                st.error(f"Error running {script}: {e}")
