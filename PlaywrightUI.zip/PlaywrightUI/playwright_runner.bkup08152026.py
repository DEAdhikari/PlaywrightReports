import streamlit as st
import subprocess
import os
import json
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from fpdf import FPDF
import time
import altair as alt

TESTS_DIR = r"D:\PlaywrightUI\tests"

st.title("🎭 Playwright Test Runner with PDF Report & Live Graph")

scripts = [f for f in os.listdir(TESTS_DIR) if f.endswith(".py")]
script_config = {}

execution_name = st.text_input("Enter a name for this execution:", value="TestExecution")

st.markdown("### Configure scripts, threads, iterations, and wait time")
num_scripts = st.number_input("How many scripts do you want to run?", min_value=1, max_value=10, value=1, step=1)

for idx in range(num_scripts):
    st.markdown(f"#### Script {idx+1}")
    cols = st.columns([2, 1, 1, 1])
    with cols[0]:
        script = st.selectbox(f"Select script {idx+1}", scripts, key=f"script_{idx}")
    with cols[1]:
        threads = st.number_input("Threads", min_value=1, max_value=20, value=1, step=1, key=f"{script}_threads_{idx}")
    with cols[2]:
        iterations = st.number_input("Iterations", min_value=1, max_value=50, value=1, step=1, key=f"{script}_iterations_{idx}")
    with cols[3]:
        wait_time = st.number_input("Wait Time (sec)", min_value=0, max_value=60, value=0, step=1, key=f"{script}_wait_{idx}")
    script_config[script] = (threads, iterations, wait_time)

def run_script(script, thread_id, iteration_id, wait_time):
    result = subprocess.run(
        ["python", script],
        capture_output=True,
        text=True,
        cwd=TESTS_DIR
    )
    if wait_time > 0:
        time.sleep(wait_time)
    return script, thread_id, iteration_id, result

if st.button("Run Scripts"):
    if not script_config:
        st.warning("Please configure at least one script.")
    else:
        start_time = datetime.now()
        script_results = {script: [] for script in script_config.keys()}

        # 👇 Placeholder for live chart
        chart_placeholder = st.empty()

        with ThreadPoolExecutor() as executor:
            futures = []
            for script, (threads, iterations, wait_time) in script_config.items():
                for t in range(1, threads+1):
                    for i in range(1, iterations+1):
                        futures.append(executor.submit(run_script, script, t, i, wait_time))

            for future in as_completed(futures):
                script, thread_id, iteration_id, result = future.result()
                steps_output = result.stdout.strip()
                if steps_output:
                    try:
                        steps = json.loads(steps_output)
                        df = pd.DataFrame(steps)
                        df["Response Time (s)"] = pd.to_numeric(df["Response Time (s)"], errors="coerce")
                        script_results[script].append(df)

                        # 👇 Compute averages so far
                        combined_all = []
                        for s, dfs in script_results.items():
                            if dfs:
                                combined = pd.concat(dfs, ignore_index=True)
                                avg_df = combined.groupby("Step")["Response Time (s)"].mean().reset_index()
                                avg_df["Response Time (s)"] = avg_df["Response Time (s)"].map(lambda x: round(x, 2))
                                combined_all.append(avg_df)
                        if combined_all:
                            live_df = pd.concat(combined_all, ignore_index=True)

                            # 👇 Update chart: X = Step, Y = Avg Response Time
                            chart = alt.Chart(live_df).mark_bar().encode(
                                x=alt.X("Step:N", sort=None),
                                y="Response Time (s):Q",
                                tooltip=["Step", "Response Time (s)"]
                            ).properties(title="Average Response Time per Transaction").interactive()

                            chart_placeholder.altair_chart(chart, use_container_width=True)

                    except json.JSONDecodeError:
                        st.warning(f"Could not parse step timings for {script}.")
                else:
                    st.warning(f"No step timings found for {script} (Thread {thread_id}, Iteration {iteration_id}).")

                if result.stderr.strip():
                    with st.expander(f"Error logs for {script}"):
                        st.error(result.stderr)

        end_time = datetime.now()
        st.success(f"Execution finished at {end_time.strftime('%H:%M:%S')}")
