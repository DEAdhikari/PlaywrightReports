A requirements.txt can only install Python packages. Playwright also needs browser binaries, so after installing, you must run:
pip install -r requirements.txt
pip install Playwright
pip install fpdf
pip install matplotlib


pytest → runs your test functions.
playwright → provides the automation API.
pytest-playwright → integrates Playwright with pytest fixtures.
streamlit → powers your test runner UI.
beautifulsoup4 → optional helper if you want to embed/parse Playwright’s HTML reports inside Streamlit.

for pushing to git check the below commands manualy
cd D:\PlaywrightUI
git add TestExecution.pdf
git commit -m "Add execution report"
git push origin main


If they work then push to git from streamlit will also work
if not then you have to install git on your machine

To initialize your folder as Git repo
go to the folder in D:\PlaywrightUI
Type the command : git init
Connect your local repo to your GitHub repo: git remote add origin https://github.com/DEAdhikari/PlaywrightReports.git
Make sure you’re on the same branch GitHub expects (main): git branch -M main
Add and Commit Your Report: 
git add TestExecution.pdf
git commit -m "Add execution report"

Push to GitHub
git push origin main


