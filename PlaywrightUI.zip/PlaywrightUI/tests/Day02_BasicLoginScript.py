# Day02_BasicLoginScript.py
import time
import json
from playwright.sync_api import sync_playwright

def run_steps():
    steps = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()

        def record_step(name, func):
            start = time.time()
            func()
            end = time.time()
            steps.append({"Step": name, "Response Time (s)": round(end - start, 2)})
            time.sleep(3)

        record_step("02_Navigate to login page",
                    lambda: page.goto("https://practicetestautomation.com/practice-test-login/"))

        record_step("02_Fill username",
                    lambda: page.fill("#username", "student"))

        record_step("02_Fill password",
                    lambda: page.fill("#password", "Password123"))

        record_step("02_Click login button",
                    lambda: page.click("#submit"))

        record_step("02_Verify redirected URL",
                    lambda: page.wait_for_url("https://practicetestautomation.com/logged-in-successfully/"))

        browser.close()
    return steps

if __name__ == "__main__":
    steps = run_steps()
    # Print JSON so Streamlit can parse easily
    print(json.dumps(steps))
