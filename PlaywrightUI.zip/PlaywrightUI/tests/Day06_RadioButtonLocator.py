# Day06_RadioButtonScript.py
import time
import json
import random
from playwright.sync_api import sync_playwright

def run_steps():
    steps = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()

        def record_step(name, func):
            start = time.time()
            func()
            end = time.time()
            steps.append({"Step": name, "Response Time (s)": round(end - start, 2)})
            time.sleep(2)  # pause for visibility

        def get_color():
            # Replace with actual IDs or labels from the page
            color_select = ['#color1', '#color2', '#color3', '#color4']
            return random.choice(color_select)

        # Step 1: Navigate to form fields page
        record_step("06_Navigate to form fields page",
                    lambda: page.goto("https://practice-automation.com/form-fields/"))

        # Step 2: Select random radio button
        random_color = get_color()
        record_step(f"06_Select radio button {random_color}",
                    lambda: page.locator(random_color).check())

        # Step 3: Verify radio button is checked
        record_step("06_Verify radio button is checked",
                    lambda: page.locator(random_color).is_checked())

        browser.close()
    return steps

if __name__ == "__main__":
    steps = run_steps()
    # Print JSON so Streamlit or logs can parse easily
    print(json.dumps(steps, indent=2))
