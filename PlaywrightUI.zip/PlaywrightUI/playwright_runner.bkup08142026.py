import streamlit as st
import subprocess
import os
import json
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from fpdf import FPDF   # install with: pip install fpdf2
import time

TESTS_DIR = r"D:\PlaywrightUI\tests"

st.title("🎭 Playwright Test Runner with PDF Report")

scripts = [f for f in os.listdir(TESTS_DIR) if f.endswith(".py")]
script_config = {}

execution_name = st.text_input("Enter a name for this execution:", value="TestExecution")

st.markdown("### Configure scripts, threads, iterations, and wait time")
num_scripts = st.number_input("How many scripts do you want to run?", min_value=1, max_value=10, value=1, step=1)

for idx in range(num_scripts):
    st.markdown(f"#### Script {idx+1}")
    cols = st.columns([2, 1, 1, 1])
    with cols[0]:
        script = st.selectbox(f"Select script {idx+1}", scripts, key=f"script_{idx}")
    with cols[1]:
        threads = st.number_input("Threads", min_value=1, max_value=20, value=1, step=1, key=f"{script}_threads_{idx}")
    with cols[2]:
        iterations = st.number_input("Iterations", min_value=1, max_value=50, value=1, step=1, key=f"{script}_iterations_{idx}")
    with cols[3]:
        wait_time = st.number_input("Wait Time (sec)", min_value=0, max_value=60, value=0, step=1, key=f"{script}_wait_{idx}")
    script_config[script] = (threads, iterations, wait_time)

def run_script(script, thread_id, iteration_id, wait_time):
    result = subprocess.run(
        ["python", script],
        capture_output=True,
        text=True,
        cwd=TESTS_DIR
    )
    # 👇 wait between iterations
    if wait_time > 0:
        time.sleep(wait_time)
    return script, thread_id, iteration_id, result

def generate_pdf_report(final_df, start_time, end_time, exec_name):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt=f"Execution Report - {exec_name}", ln=True, align="C")
    pdf.ln(10)
    pdf.cell(200, 10, txt=f"Start Time: {start_time.strftime('%Y-%m-%d %H:%M:%S')}", ln=True)
    pdf.cell(200, 10, txt=f"End Time: {end_time.strftime('%Y-%m-%d %H:%M:%S')}", ln=True)
    pdf.cell(200, 10, txt=f"Total Duration: {str(end_time - start_time)}", ln=True)
    pdf.ln(10)
    col_widths = [80, 50, 50]
    headers = ["Step", "Response Time (s)", "Total Iterations"]
    for i, header in enumerate(headers):
        pdf.cell(col_widths[i], 10, header, border=1)
    pdf.ln()
    pdf.set_font("Arial", size=10)
    for _, row in final_df.iterrows():
        y_before = pdf.get_y()
        x_before = pdf.get_x()
        pdf.multi_cell(col_widths[0], 10, str(row["Step"]), border=1)
        y_after = pdf.get_y()
        row_height = y_after - y_before
        pdf.set_xy(x_before + col_widths[0], y_before)
        pdf.multi_cell(col_widths[1], 10, str(row["Response Time (s)"]), border=1)
        pdf.set_xy(x_before + col_widths[0] + col_widths[1], y_before)
        pdf.multi_cell(col_widths[2], 10, str(row["Total Iterations Executed"]), border=1)
        pdf.set_y(y_before + row_height)
    pdf_file = f"{exec_name}.pdf"
    pdf.output(pdf_file)
    return pdf_file

if st.button("Run Scripts"):
    if not script_config:
        st.warning("Please configure at least one script.")
    else:
        start_time = datetime.now()
        script_results = {script: [] for script in script_config.keys()}
        with ThreadPoolExecutor() as executor:
            futures = []
            for script, (threads, iterations, wait_time) in script_config.items():
                for t in range(1, threads+1):
                    for i in range(1, iterations+1):
                        futures.append(executor.submit(run_script, script, t, i, wait_time))
            for future in as_completed(futures):
                script, thread_id, iteration_id, result = future.result()
                steps_output = result.stdout.strip()
                if steps_output:
                    try:
                        steps = json.loads(steps_output)
                        df = pd.DataFrame(steps)
                        df["Response Time (s)"] = pd.to_numeric(df["Response Time (s)"], errors="coerce")
                        script_results[script].append(df)
                    except json.JSONDecodeError:
                        st.warning(f"Could not parse step timings for {script}.")
                else:
                    st.warning(f"No step timings found for {script} (Thread {thread_id}, Iteration {iteration_id}).")
                if result.stderr.strip():
                    with st.expander(f"Error logs for {script}"):
                        st.error(result.stderr)
        end_time = datetime.now()
        combined_all = []
        for script, dfs in script_results.items():
            if dfs:
                combined = pd.concat(dfs, ignore_index=True)
                avg_df = combined.groupby("Step")["Response Time (s)"].mean().reset_index()
                avg_df["Response Time (s)"] = avg_df["Response Time (s)"].map(lambda x: f"{x:.2f}")
                threads, iterations, wait_time = script_config[script]
                total_iterations = threads * iterations
                avg_df["Total Iterations Executed"] = total_iterations
                combined_all.append(avg_df)
        if combined_all:
            final_df = pd.concat(combined_all, ignore_index=True)
            st.markdown("## 📊 Combined Averaged Results")
            st.dataframe(final_df)
            pdf_file = generate_pdf_report(final_df, start_time, end_time, execution_name)
            with open(pdf_file, "rb") as f:
                st.download_button("📥 Download Execution Report (PDF)", f, file_name=pdf_file)
